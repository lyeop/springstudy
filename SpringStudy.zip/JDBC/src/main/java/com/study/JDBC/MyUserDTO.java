package com.study.JDBC;

import lombok.Data;

@Data
public class MyUserDTO {
    private String id;
    private String name;
}
