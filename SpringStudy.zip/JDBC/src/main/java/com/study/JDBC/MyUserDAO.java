package com.study.JDBC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository // 저장소 -> 컨테이너에 올라감
public class MyUserDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<MyUserDTO> list() {
        String query = "select * from myuser";
        List<MyUserDTO> list = jdbcTemplate.query(query, new BeanPropertyRowMapper<MyUserDTO>(MyUserDTO.class));

        /*
        for(UserDTO my : list) {
        System.out.println(my);
         */
        return list;
    }
}
