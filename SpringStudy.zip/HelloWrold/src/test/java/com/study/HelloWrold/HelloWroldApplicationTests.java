package com.study.HelloWrold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWroldApplicationTests {

	@Test
	void contextLoads() {
	}

}
