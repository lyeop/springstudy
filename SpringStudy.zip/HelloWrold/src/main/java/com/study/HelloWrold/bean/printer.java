package com.study.HelloWrold.bean;

public interface printer {

    public void print(String message);
}
