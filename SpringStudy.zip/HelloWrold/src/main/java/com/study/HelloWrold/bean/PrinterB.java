package com.study.HelloWrold.bean;


import org.springframework.stereotype.Component;

@Component("printerB")
public class PrinterB implements printer{

    @Override
    public void print(String message){
        System.out.println("Printer B : " + message);
    }

}
