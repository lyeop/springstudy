package com.study.HelloWrold.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Member {

    private String name;

    private String nickname;
    @Autowired
    @Qualifier("printerA")
    private printer printer;

    public printer getPrinter() {
        return printer;
    }

    public void setPrinter(printer printer) {
        this.printer = printer;
    }

    public  Member(){};
    public Member(String name ,String nickname, printer printer){
        this.name=name;
        this.nickname=nickname;
        this.printer=printer;
    }
    public String getName(){
        return name;
    }
    public String getNickname(){
        return nickname;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void print(){
        printer.print("HEllo" + name+" : "+ nickname);

    }
}
