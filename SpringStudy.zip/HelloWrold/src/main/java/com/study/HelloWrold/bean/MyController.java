package com.study.HelloWrold.bean;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
    @RequestMapping("/")
    public @ResponseBody String root(){
        // @responseBody 입력시 화면에 바로 출력/입력 안할시 helloWorld!.jsp를 찾는다.
        return "Hellow world!";
    }
}
