package com.study.HelloWrold.bean;


import org.springframework.stereotype.Component;

@Component("printerA")
public class PrinterA implements printer {

    @Override
    public void print(String message){
        System.out.println("Printer A : " + message);
    }
}
