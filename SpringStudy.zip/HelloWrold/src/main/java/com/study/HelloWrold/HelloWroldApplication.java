package com.study.HelloWrold;

import com.study.HelloWrold.bean.Config;
import com.study.HelloWrold.bean.Member;
import com.study.HelloWrold.bean.printer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.format.Printer;



@SpringBootApplication //스프링 부트 시작 <- 의존성
public class HelloWroldApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloWroldApplication.class, args);

		//IOC 컨테이너 생성
		ApplicationContext context=
				new AnnotationConfigApplicationContext(Config.class);

		//2. Member Bean 가져오기
		Member member1 = (Member) context.getBean("member1");
		member1.print();

		//3. Member Bean 가져오기
		Member member2 = context.getBean("hello" , Member.class);
		member2.print();


		printer printer= context.getBean("printerB",printer.class);
		member1.setPrinter(printer);
		member1.print();

		if(member1==member2){
			System.out.println("서로 같은 객체 입니다.");
		}
		else{
			System.out.println("서로 다른 객체 입니다.");
		}

		Member member3 = (Member) context.getBean("member1");

		if(member1==member3){
			System.out.println("서로 같은 객체 입니다.");
		}
		else{
			System.out.println("서로 다른 객체 입니다.");
		}

	}



}
