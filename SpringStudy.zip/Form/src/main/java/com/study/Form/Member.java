package com.study.Form;

import lombok.Data;

@Data //Getter, Setter , toString 자동 적용
public class Member {
    private String id;
    private String name;


}
