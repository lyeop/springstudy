package com.study.MyBatis_SimpleBBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBatisSimpleBbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
