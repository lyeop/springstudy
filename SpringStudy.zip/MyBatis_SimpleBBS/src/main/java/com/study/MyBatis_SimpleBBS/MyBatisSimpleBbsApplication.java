package com.study.MyBatis_SimpleBBS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBatisSimpleBbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBatisSimpleBbsApplication.class, args);
	}

}
