package com.study.MyBatis_SimpleBBS;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface ISimpleBbsDao {
    public List<SimpleBbsDto> listDao();
    public SimpleBbsDto viewDao(String id);
    public int writeDao(Map<String, String>map);
    public int deleteDao(@Param("_id") String id);
    public int deleteDao1();
    public int deleteDao2();
    public int deleteDao3();

    public int articleCount();

}
