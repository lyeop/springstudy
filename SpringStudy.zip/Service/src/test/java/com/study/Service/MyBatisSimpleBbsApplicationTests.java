package com.study.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBatisSimpleBbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
