package com.study.Service;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ISimpleBbsService {

    public List<SimpleBbsDto> list();
    public SimpleBbsDto view(String id);
    public int write(Map<String, String> map);
    public int delete(@Param("_id") String id);
    public int delete1();
    public int delete2();
    public int delete3();

    public int count();
}
