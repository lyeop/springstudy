package com.study.Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBatisSimpleBbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBatisSimpleBbsApplication.class, args);
	}

}
