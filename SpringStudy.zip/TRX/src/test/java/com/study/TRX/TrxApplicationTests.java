package com.study.TRX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrxApplicationTests {

	@Test
	void contextLoads() {
	}

}
