package com.study.TRX;

import lombok.Data;

@Data
public class Transaction2Dto {
    private String consumerId;
    private int amount;
}
