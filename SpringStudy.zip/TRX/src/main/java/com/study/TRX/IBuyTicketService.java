package com.study.TRX;

public interface IBuyTicketService {
    public int buy(String consumerId,int money,String error);
}
