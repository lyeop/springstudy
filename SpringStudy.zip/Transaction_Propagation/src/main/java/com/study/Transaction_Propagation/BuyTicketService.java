package com.study.Transaction_Propagation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

@Service
public class BuyTicketService {
    @Autowired
    ITransaction1Dao transaction1;
    @Autowired
    ITransaction2Dao transaction2;

//    @Autowired
//    PlatformTransactionManager transactionManager;
//    @Autowired
//    TransactionDefinition definition;
    @Autowired
    TransactionTemplate transactionTemplate;
    @Transactional(propagation = Propagation.REQUIRED)

    public int buy(String consumerId,int amount,String error){


        try{
            transactionTemplate.execute(new TransactionCallbackWithoutResult() {
                @Override
                protected void doInTransactionWithoutResult(TransactionStatus arg0) {
                    transaction1.pay(consumerId,amount);
                    //의도적 에러 발생

                    if (error.equals("1")){ //zero로 나눌수 없기에 에러
                        int n= 10/0;

                    }
                    transaction2.pay(consumerId,amount);

                }
            });

            return 1;
        }catch (Exception e){
            System.out.println("[Transaction Propagtion #2]  Rollback");

            return 0;
        }
    }
}
