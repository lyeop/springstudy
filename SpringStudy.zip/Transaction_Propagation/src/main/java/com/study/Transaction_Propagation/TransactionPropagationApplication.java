package com.study.Transaction_Propagation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionPropagationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionPropagationApplication.class, args);
	}

}
