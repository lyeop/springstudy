package com.study.Transaction_Propagation;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ITransaction3Dao {
    public void pay(String consumerId, int amount);
}
