package com.study.Transaction_Propagation;

import lombok.Data;

@Data
public class Transaction2Dto {
    private String consumerId;
    private int amount;
}
