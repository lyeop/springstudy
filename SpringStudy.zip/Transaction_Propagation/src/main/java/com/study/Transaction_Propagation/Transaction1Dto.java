package com.study.Transaction_Propagation;

import lombok.Data;

@Data
public class Transaction1Dto {
    private String consumerId;
    private int amount;
}
