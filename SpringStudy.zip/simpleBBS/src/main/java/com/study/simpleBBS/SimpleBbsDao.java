package com.study.simpleBBS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BatchProperties;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SimpleBbsDao implements ISimpleBbsDao{
    @Autowired
    JdbcTemplate template;

    @Override
    public List<SimpleBbsDto> listDao(){
        System.out.println("listDao()");

        String query = "select *from simple_bbs order by id desc";
        //쿼리문 실행 JdbcTemplate -> 쿼리문 실행 결과 List<SimpleBbsDto>
        //SimpleBbsDto (SimpleBbsDto.class)
        List<SimpleBbsDto> dtos =template.query(
                query, new BeanPropertyRowMapper<SimpleBbsDto>(SimpleBbsDto.class)
        );
        return dtos;
    }
    @Override
    public SimpleBbsDto viewDao(String id){
        System.out.println("viewDao()");

        String query = "select * from simple_bbs where id= "+id;
        SimpleBbsDto dto = template.queryForObject(query, new BeanPropertyRowMapper<SimpleBbsDto>(SimpleBbsDto.class));

        return dto;
    }
    @Override
    public int writeDao(final String writer, final String title,final String content){
        System.out.println("writeDao()");

        String query = "insert into simple_bbs (id,writer,title,content)"+
                "values (null,?,?,?)";
        return template.update(query,writer,title,content);
    }
    @Override
    public int deleteDao(final String id){
        System.out.println("deleteDao()");

        String query = "delete from simple_bbs where id = ?";
        return template.update(query,Integer.parseInt(id));
    }
    @Override
    public int deleteDao1(){
        String query=
                "SET @id := 0";
        return template.update(query);
    }
    @Override
    public int deleteDao2(){
        String query=
                "UPDATE simple_bbs SET id = @id := @id + 1";
        return template.update(query);
    }
    @Override
    public int deleteDao3(){
        String query=
                "ALTER TABLE simple_bbs AUTO_INCREMENT = 1";
        return template.update(query);
    }
}
