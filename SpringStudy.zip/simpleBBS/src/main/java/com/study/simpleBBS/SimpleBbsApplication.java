package com.study.simpleBBS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleBbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleBbsApplication.class, args);
	}

}
