package com.study.simpleBBS;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

    @Autowired //컨테이너 객체 연결 ISimpleBbsDao -> interface
    ISimpleBbsDao dao;

    @RequestMapping("/")
    public String root() throws Exception{
        //JdbcTemplate : SimpleBBS
        //redirect 리로더 다시 돌린다. ->list
        return "redirect:list";
    }
    @RequestMapping("/list")
    public String userlistPage(Model model){
        model.addAttribute("list",dao.listDao());
        return "list";
    }
    @RequestMapping("/view")
    public String view(HttpServletRequest request, Model model){
        String sId = request.getParameter("id");
        model.addAttribute("dto",dao.viewDao(sId));
        return "view";
    }
    @RequestMapping("/writeForm")
    public String writeForm(){
        return "writeForm";
    }
    @RequestMapping("/write")
    public String write(Model model, HttpServletRequest request){
        dao.writeDao(request.getParameter("writer"),request.getParameter("title"),request.getParameter("content"));
        return "redirect:list";
    }
    @RequestMapping("/delete")
    public String delete(HttpServletRequest request, Model model){
        dao.deleteDao(request.getParameter("id"));
        dao.deleteDao1();
        dao.deleteDao2();
        dao.deleteDao3();
        return "redirect:list";
    }

}
