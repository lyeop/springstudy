package com.study.simpleBBS;

import java.util.List;

public interface ISimpleBbsDao {

    public List<SimpleBbsDto> listDao();
    public SimpleBbsDto viewDao(String id);
    public int writeDao(String writer, String title, String content);
    public int deleteDao(String id);
    public int deleteDao1();
    public int deleteDao2();
    public int deleteDao3();
}
