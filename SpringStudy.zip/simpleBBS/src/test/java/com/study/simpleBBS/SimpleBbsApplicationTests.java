package com.study.simpleBBS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
