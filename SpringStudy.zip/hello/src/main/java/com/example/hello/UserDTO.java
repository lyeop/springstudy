package com.example.hello;

import lombok.Data;

@Data
public class UserDTO {
    private String name;
    private int age;
}
