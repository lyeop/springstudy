package com.study.MyBatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
