package com.study.WebBasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
