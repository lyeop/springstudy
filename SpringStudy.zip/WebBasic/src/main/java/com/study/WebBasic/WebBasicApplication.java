package com.study.WebBasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebBasicApplication.class, args);
	}

}
