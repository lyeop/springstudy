package com.study.ValidationUtils;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationUtilsApplicationTests {

	@Test
	void contextLoads() {
	}

}
