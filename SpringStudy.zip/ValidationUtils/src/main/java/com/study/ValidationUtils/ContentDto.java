package com.study.ValidationUtils;

import lombok.Data;

@Data
public class ContentDto {
    private int id;
    private String writer;
    private String content;
}
