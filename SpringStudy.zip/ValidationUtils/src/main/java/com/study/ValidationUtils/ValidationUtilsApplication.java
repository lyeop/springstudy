package com.study.ValidationUtils;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationUtilsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationUtilsApplication.class, args);
	}

}
